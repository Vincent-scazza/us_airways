
type Brand = {
    // ? représente la valeur null
    id?: number,
    name?: string,
};

export default Brand;