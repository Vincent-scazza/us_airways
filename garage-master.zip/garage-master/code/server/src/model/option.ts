
type Option = {
    // ? représente la valeur null
    id?: number,
    name?: string,
};

export default Option;