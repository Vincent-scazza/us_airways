type Role = {
	id?: number;
	name?: string;
};

export default Role;
